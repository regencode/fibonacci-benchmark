#include <stdio.h>
#include "mylib/mylib.h"

int main(){

    while(1){
        fibIterative(10000);
    }
    
    return 0;
}