#include <stdio.h>
#include "mylib/mylib.h"

int main(){

    while(1){
        fibRecursive(10000);
    }

    return 0;
}