

int fibIterative(unsigned int N);

int fibRecursive(unsigned int N);